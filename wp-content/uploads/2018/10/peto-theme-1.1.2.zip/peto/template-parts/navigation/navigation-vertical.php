<?php
/**
 * Displays top vertical
 *
 * @package WordPress
 * @subpackage peto
 * @since 1.0
 * @version 1.0
 */

?>
	<?php wp_nav_menu( array(
		'theme_location' => 'vertical',
		'menu_id'        => 'vertical-menu',
	) ); ?>