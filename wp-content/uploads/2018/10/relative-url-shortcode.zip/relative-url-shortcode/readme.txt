=== Relative URL ShortCode ===
Contributors: mainsufian
Donate link: #
Tags: addShortCode, ShortCode, wordpress, Relative_URL, url, Relative, URLShortCode, AbsoluteUrl, absolute, a , links, RelativeLinks , AbsoluteLinks, baseUrlShortcode , BaseUrl, SiteUrl, subdomain , subdomainUrl , RelativeImage, img, RelativeImg
Requires at least: 3.0.1
Tested up to: 4.4.2
Stable tag: 4.3
License: GPLv2 or later
License URI: http://www.gnu.org/licenses/gpl-2.0.html

Now its easy to change domains and keep links and images fine you just need to use this shortcode [base_url] as your base url for links and images.

== Description ==

Now its easy to change domains and move your wordpress blog from subdomain to parent domain like from localhost to live domain you just need to use this shortcode [base_url] as your base url and images So now all links and images are fine after transfer site from localhost to live you don't need to adjust links after change domain.

ShortCode
[base_url]
   
== Installation ==

** From your WordPress dashboard **

Visit 'Plugins > Add New'
Search for 'Relative URL ShortCode'
Activate 'Relative URL ShortCode' from your Plugins page.

** From WordPress.org **

Download 'Relative URL ShortCode'.
Upload the 'Relative URL ShortCode' directory to your '/wp-content/plugins/' directory, using your favorite method (ftp, sftp, scp, etc...)
Activate 'Relative URL ShortCode' from your Plugins page.


== Frequently Asked Questions ==

= I need to change something after change domain? =

No. we always use your site base url so you do not need any configuration for change domain.

= I need to change any configuration after activate? =

No. we always use your site base url so you do not need any configuration after activate.

== Screenshots ==

1. You can see diffrance in normal link and normal image in wordpress and in link and image with ShorCode.

== Changelog ==

= 1.0 =
* it is a first version.
